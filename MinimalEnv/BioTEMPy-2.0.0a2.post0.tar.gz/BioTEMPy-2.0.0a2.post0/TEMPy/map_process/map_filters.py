"""
Module with the `Filter` class.

:class:`Filter`: Object pointing to map data and holds
                 a set of methods for filtering MRC format maps.
"""
import copy
import os
import math

import numpy as np
from scipy.ndimage import measurements

from TEMPy.map_process.process import MapEdit

# For CCP-EM mac install.
try:
    from TEMPy.graphics.show_plot import Plot
except RuntimeError:
    Plot = None

try:
    import pyfftw
    pyfftw_flag = True
except ImportError:
    pyfftw_flag = False


class Filter(MapEdit):

    def __init__(self, MapInst, copy_=False):
        if type(MapInst) is MapEdit:
            if not copy_:
                self.__dict__ = MapInst.__dict__.copy()
            else:
                self.__dict__ = copy.deepcopy(MapInst.__dict__.copy())
        else:
            super(Filter, self).__init__(MapInst)

        # CHECK DEPENDENCIES
        try:
            import pyfftw  # noqa:F401
            self.pyfftw_flag = True
        except ImportError:
            self.pyfftw_flag = False

    def copy(self, deep=True):
        """
        Copy contents to a new object
        """
        # create MapEdit object
        copymap = self.__class__(self.mrc)
        copymap.origin = copy.deepcopy(self.origin)
        if deep:
            copymap.fullMap = self.fullMap.copy()
        else:
            copymap.fullMap = self.fullMap
        copymap.apix = copy.deepcopy(self.apix)
        copymap.dim = copy.deepcopy(self.dim)
        return copymap

    def label_patches(self, contour, prob=0.1, inplace=False):
        """
        Remove small isolated densities
        Arguments:
            *contour*
                map threshold
            *prob*
                fraction of a size (+-) among all sizes
        """
        fp = self.grid_footprint()
        binmap = self.fullMap > float(contour)
        label_array, labels = measurements.label(
            self.fullMap*binmap,
            structure=fp,
        )
        sizes = measurements.sum(binmap, label_array, range(labels + 1))

        if labels <= 10:
            m_array = sizes < 0.05 * sizes.max()
            ct_remove = np.sum(m_array)
            remove_points = m_array[label_array]
            label_array[remove_points] = 0
            if inplace:
                self.fullMap[:] = (label_array > 0) * (self.fullMap * binmap)
            else:
                newmap = self.copy()
                newmap.fullMap[:] = (label_array > 0) * (self.fullMap * binmap)
                return newmap, labels - ct_remove
            return labels - ct_remove + 1

        means = measurements.mean(
            self.fullMap * binmap,
            label_array,
            range(labels + 1),
        )
        freq, bins = np.histogram(sizes[1:], 20)

        m_array = np.zeros(len(sizes))
        ct_remove = 0
        for i in range(len(freq)):
            fr = freq[i]
            s2 = bins[i+1]
            s1 = bins[i]
            p_size = float(fr)/float(np.sum(freq))
            if p_size > prob:
                m_array = m_array + (
                    (sizes >= s1) &
                    (sizes < s2) &
                    (
                        means < (
                            float(contour) +
                            0.25 *
                            (np.amax(self.fullMap) - float(contour))
                        )
                    )
                )
                ct_remove += 1
        m_array = m_array > 0
        remove_points = m_array[label_array]

        label_array[remove_points] = 0
        if inplace:
            self.fullMap[:] = (label_array > 0) * (self.fullMap * binmap)
        else:
            newmap = self.copy()
            newmap.fullMap[:] = (label_array > 0) * (self.fullMap * binmap)
            return newmap, labels - ct_remove
        return labels - ct_remove

    def make_fourier_shell(self):
        """
        For a given grid, make a grid with sampling
        frequencies in the range (0:0.5)
        Return:
            grid with sampling frequencies
        """
        # set frequencies in the range -0.5 to 0.5
        rad_z = np.float32(
            np.arange(
                np.floor(self.z_size() / 2.0) * -1,
                np.ceil(self.z_size() / 2.0)) / (np.floor(self.z_size()) * 1.0)
        )
        rad_y = np.float32(
            np.arange(
                np.floor(self.y_size() / 2.0) * -1,
                np.ceil(self.y_size() / 2.0)) / (np.floor(self.y_size()) * 1.0)
        )
        rad_x = np.float32(
            np.arange(
                np.floor(self.x_size() / 2.0) * -1,
                np.ceil(self.x_size() / 2.0)) / (np.floor(self.x_size()) * 1.0)
            )

        rad_x = rad_x**2
        rad_y = rad_y**2
        rad_z = rad_z**2

        dist = np.sqrt(rad_z[:, None, None] + rad_y[:, None] + rad_x)
        return dist

    def fourier_transform(self):
        """
        pythonic FFTs for maps
        """
        if pyfftw_flag:
            output_dtype = 'complex64'
            fftoutput = pyfftw.n_byte_align_empty(
                self.fullMap.shape,
                n=16,
                dtype=output_dtype,
            )
            '''
            if not input_dtype in ['float32','float64','longdouble']:
                input_dtype = 'float32'
            elif input_dtype == 'float64':
                output_dtype = 'complex128'
            elif input_dtype == 'longdouble':
                output_dtype = 'clongdouble'

            #for r2c transforms:
            output_array_shape = \
                    self.fullMap.shape[:len(self.fullMap.shape)-1]+ \
                                        (self.fullMap.shape[-1]//2 + 1,)
            fftoutput = pyfftw.n_byte_align_empty(output_array_shape,
                                            n=16, dtype=output_dtype)
            #check if array is byte aligned
            #TODO: can we read the map file as byte aligned?
            if pyfftw.is_byte_aligned(self.fullMap):
                fft = pyfftw.FFTW(self.fullMap,fftoutput,
                                  direction='FFTW_FORWARD',axes=(0,1,2),
                                  flags=['FFTW_ESTIMATE'])
                flag_alignedarray = 0
            else:
            '''
            inputarray = pyfftw.empty_aligned(
                self.fullMap.shape,
                n=16,
                dtype='complex64'
            )
            fft = pyfftw.FFTW(
                inputarray,
                fftoutput,
                direction='FFTW_FORWARD', axes=(0, 1, 2),
                flags=['FFTW_ESTIMATE']
            )
            inputarray[:, :, :] = self.fullMap
            fft()
        else:
            # TODO: warning raises error in tasks
            print('PyFFTw not found!, using numpy fft')
            fftoutput = np.fft.fftn(self.fullMap)
        # TODO: set header for ftmaps
        ftmap = self.copy(deep=False)
        ftmap.fullMap = fftoutput
        if pyfftw_flag:
            del inputarray
        return ftmap

    def inv_fourier_transform(
            self,
            ftmap,
            output_dtype=None,
            output_shape=None
    ):
        """
        Calculate inverse fourier transform
        """
        if pyfftw_flag:
            input_dtype = str(ftmap.fullMap.dtype)
            '''
            if output_array_dtype is None: output_array_dtype = 'float32'
            if not input_dtype in ['complex64','complex128','clongdouble']:
                input_dtype = 'complex64'
            elif input_dtype == 'complex128':
                output_array_dtype = 'float64'
            elif input_dtype == 'clongdouble':
                output_array_dtype = 'longdouble'

            #for c2r transforms:
            if output_shape is None: output_shape = \
                                    ftmap.fullMap.shape[:len(ftmap.fullMap.shape)-1]+\
                                    ((ftmap.fullMap.shape[-1] - 1)*2,)
            '''
            output_shape = ftmap.fullMap.shape
            output_array_dtype = 'complex64'
            output_array = pyfftw.empty_aligned(
                output_shape,
                n=16,
                dtype=output_array_dtype,
            )
            # check if array is byte aligned
            if pyfftw.is_byte_aligned(ftmap.fullMap):
                ifft = pyfftw.FFTW(
                    ftmap.fullMap,
                    output_array,
                    direction='FFTW_BACKWARD',
                    axes=(0, 1, 2),
                    flags=['FFTW_ESTIMATE'],
                )
            else:

                inputarray = pyfftw.n_byte_align_empty(
                    ftmap.fullMap.shape,
                    n=16,
                    dtype=input_dtype
                )
                ifft = pyfftw.FFTW(
                    inputarray, output_array,
                    direction='FFTW_BACKWARD',
                    axes=(0, 1, 2),
                    flags=['FFTW_ESTIMATE'],
                )
                inputarray[:, :, :] = ftmap.fullMap[:, :, :]
            ifft()
        else:
            # TODO: warnings raises error in tasks
            print('PyFFTw not found!, using numpy ifft')
            output_array = np.real(np.fft.ifftn(ftmap.fullMap))
        # TODO: set invftmap header
        invftmap = self.copy(deep=False)
        if output_dtype is None:
            invftmap.fullMap = output_array.real.astype(np.float32, copy=False)
        else:
            try:
                invftmap.fullMap = output_array.real.astype(
                    output_dtype,
                    copy=False,
                )
            except:  # noqa: E722 TODO: Catch specific errors
                invftmap.fullMap = output_array.real.astype(
                    np.float32,
                    copy=False
                )

        del ftmap.fullMap
        return invftmap

    def fourier_filter(
            self,
            ftfilter,
            inplace=False,
            plot=False,
            plotfile='plot',
    ):
        """
        Apply lowpass/highpass/bandpass filters in fourier space

        ftfilter: filter applied on the fourier grid
        """

        ftmap = self.fourier_transform()
        if plot:
            dict_plot = {}
            lfreq, shell_avg = self.get_raps(np.fft.fftshift(ftmap.fullMap))
            dict_plot['map'] = [lfreq[:], shell_avg[:]]
        # shift zero frequency to the center and apply the filter
        ftmap.fullMap[:] = np.fft.fftshift(ftmap.fullMap) * ftfilter
        if plot:
            lfreq, shell_avg = self.get_raps(ftmap_filt)  # noqa: F821 TODO:fix
            dict_plot['filtered'] = [lfreq, shell_avg]
            self.plot_raps(dict_plot, plotfile=plotfile)
        ftmap.fullMap[:] = np.fft.ifftshift(ftmap.fullMap)
        invftmap = self.inv_fourier_transform(
            ftmap,
            output_shape=self.fullMap.shape
        )
        if inplace:
            self.fullMap = invftmap.fullMap
        else:
            newmap = self.copy(deep=False)
            newmap.fullMap = invftmap.fullMap
            return newmap

    @staticmethod
    def apply_filter(ftmap, ftfilter, inplace=False):
        # fftshifted ftmap
        if inplace:
            ftmap.fullMap[:] = ftmap.fullMap * ftfilter
            return ftmap
        else:
            filteredmap = ftmap.copy()
            filteredmap.fullMap[:] = ftmap.fullMap * ftfilter
            return filteredmap

    def get_raps(self, ftmap, step=0.02):
        """
        Get rotationally averaged power spectra from fourier (filtered) map
        ftmap : fourier map (e.g. with any filter appied)
        step : frequency shell width [0:0.5]
        """
        dist = self.make_fourier_shell() / max(self.apix)
        maxlevel = 0.5 / max(self.apix)
        step = step / max(self.apix)
        x = 0.0
        nc = 0
        shell_avg = []
        lfreq = []
        highlevel = x + step
        while (x <= maxlevel - step):
            fshells = ((dist < min(maxlevel, highlevel)) & (dist >= x))
            try:
                shellvec = np.take(
                    ftmap.ravel(),
                    np.where(fshells.ravel())
                )
            except:  # noqa:E722
                shellvec = ftmap[fshells]

            shellabs = abs(shellvec)
            nshellzero = len(np.flatnonzero(shellabs))

            if nshellzero < 5:
                if highlevel == maxlevel:
                    break
                nc += 1
                highlevel = min(maxlevel, x + (nc + 1) * step)
                continue
            else:
                nc = 0
            shell_avg.append(np.log10(np.mean(np.square(shellabs))))
            lfreq.append((x + (highlevel - x) / 2.))
            x = highlevel
            highlevel = x + step
        del fshells, shellvec, shellabs
        return lfreq, shell_avg

    def plot_raps(self, dict_plot, plotfile='plot'):
        if Plot is not None:
            plt = Plot()
            plt.lineplot(dict_plot, plotfile)

    def tanh_lowpass(self, cutoff, fall=0.5):
        """
        Lowpass filter with a hyperbolic tangent function

        cutoff: high frequency cutoff [0:0.5]
        fall: smoothness of falloff [0-> tophat,1.0-> gaussian]
        Return:
            tanh lowpass filter to apply on fourier map
        """
        if fall == 0.0:
            fall = 0.01
        drop = math.pi / (2 * float(cutoff) * float(fall))
        cutoff = min(float(cutoff), 0.5)
        dist = self.make_fourier_shell()
        dist1 = dist + cutoff
        dist1[:] = drop * dist1
        dist1[:] = np.tanh(dist1)
        dist[:] = dist - cutoff
        dist[:] = drop * dist
        dist[:] = np.tanh(dist)
        dist[:] = dist1 - dist
        dist = 0.5 * dist
        del dist1
        return dist

    def tanh_bandpass(
            self,
            low_cutoff=0.0,
            high_cutoff=0.5,
            low_fall=0.1,
            high_fall=0.1
    ):
        """
        Bandpass filter with a hyperbolic tangent function
        low_cutoff: low frequency cutoff [0:0.5]
        high-cutoff : high frequency cutoff [0:0.5]
        fall: determines smoothness of falloff [0-> tophat,1.0-> gaussian]
        Return:
            tanh lowpass filter to apply on fourier map
        """
        low_drop = math.pi / (2 * float(high_cutoff - low_cutoff) *
                              float(low_fall))
        high_drop = math.pi / (2 * float(high_cutoff - low_cutoff) *
                               float(high_fall))

        dist = self.make_fourier_shell()
        return 0.5 * (
                np.tanh(high_drop * (dist + high_cutoff)) -
                np.tanh(high_drop * (dist - high_cutoff)) -
                np.tanh(low_drop * (dist + low_cutoff)) +
                np.tanh(low_drop * (dist - low_cutoff))
        )

    def butterworth_lowpass(self, pass_freq):
        """
        Lowpass filter with a gaussian function
        pass_freq : low-pass cutoff frequency [0:0.5]
        """
        eps = 0.882
        a = 10.624
        high_cutoff = 0.15 * math.log10(1.0 / pass_freq) + pass_freq

        fall = 2.0 * (math.log10(eps / math.sqrt(a**2 - 1)) /
                      math.log10(pass_freq / float(high_cutoff)))

        cutoff_freq = float(pass_freq) / math.pow(eps, 2 / fall)

        dist = self.make_fourier_shell()
        dist = dist/cutoff_freq
        return np.sqrt(1.0 / (1.0 + np.power(dist, fall)))

    def gauss_bandpass(self, sigma, center=0.0):
        """
        Bandpass filter with a gaussian function
        sigma : cutoff frequency [0:0.5]
        """
        dist = self.make_fourier_shell()
        return np.exp(
            -((dist - center)**2) / (2 * sigma * sigma)
        )

    def gauss_lowpass(self, sigma):
        """
        Bandpass filter with a gaussian function
        sigma : cutoff frequency [0:0.5]
        """
        dist = self.make_fourier_shell()
        return np.exp(
            -(dist**2) / (2 * sigma * sigma)
        )


if __name__ == '__main__':
    import mrcfile
    mapfile = "/Users/agnel/data/map_model/gs/emd_3061.map"
    mrcobj = mrcfile.open(mapfile, mode='r+')
    mrcfilt = Filter(mrcobj)
    ftfilter = mrcfilt.tanh_lowpass(0.2, fall=0.5)
    mrcfilt.fourier_filter(ftfilter, plot=True, plotfile='tanh0_2f0_5')
    map_name = os.path.basename(os.path.splitext(mapfile)[0])
    map_dir = os.path.dirname(os.path.abspath(mapfile))
    newmap = mrcfile.new(
        os.path.join(
            map_dir,
            map_name+'_modified.mrc'
        ),
        overwrite=True
    )
    mrcfilt.set_newmap_data_header(newmap)
    newmap.close()
