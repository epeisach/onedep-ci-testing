from TEMPy.core.errors.instance import InstanceError

__all__ = [
    InstanceError
]
