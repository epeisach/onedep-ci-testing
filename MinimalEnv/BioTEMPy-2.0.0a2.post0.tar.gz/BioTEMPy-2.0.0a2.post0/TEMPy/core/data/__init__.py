from TEMPy.core.data.download import DownloadData

__all__ = [
    DownloadData
]
